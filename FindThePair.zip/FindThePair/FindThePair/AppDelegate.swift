//
//  AppDelegate.swift
//  FindThePair
//
//  Created by koilubaev_barsbek on 19/12/24.
//

//
//  AppDelegate.swift
//  FirebaseExample
//
//  Created by Ian Solomein on 15.08.2020.
//  Copyright © 2020 Ian Solomein. All rights reserved.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth

@main
struct FindThePairApp: App {
    init() {
        FirebaseApp.configure() // Инициализация Firebase
    }
    
    var body: some Scene {
        WindowGroup {
            if Auth.auth().currentUser != nil {
                SignInView() // Показываем экран входа, если пользователь не авторизован
            } else {
                SignInView() // Если не зарегистрирован, показываем экран регистрации
            }
        }
    }
}
