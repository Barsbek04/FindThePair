//
//  Model.swift
//  FindThePair
//
//  Created by koilubaev_barsbek on 10/12/24.
//

import Foundation
