//
//  GameViewModel.swift
//  FindThePair
//
//  Created by koilubaev_barsbek on 10/12/24.
//
import SwiftUI
import FirebaseCore
import FirebaseAuth

class GameViewModel: ObservableObject {
    @Published var cards: [Card] = [] // Массив карточек
    @Published var moves: Int = 0 // Количество ходов
    @Published var matchedPairs: Int = 0 // Количество найденных пар
    @Published var gameCompleted: Bool = false // Флаг завершения игры
    
    private var flippedCards: [Card] = [] // Хранит 2 перевернутые карточки для проверки совпадений
    private var record: Int = Int.max // Рекорд по количеству ходов, по умолчанию - максимальное значение
    
    init() {
        startGame() // Запускаем игру при инициализации
    }
    
    /// Функция для начала новой игры
    func startGame() {
        let images = ["Argentina", "Brazil", "Kyrgystan", "China", "Kazakhstan", "England", "Spani", "Japan"] // 8 различных изображений
        var gameCards = images + images // Дублируем изображения для создания пар (8 пар)
        gameCards.shuffle() // Перемешиваем
        
        // Создаем массив карточек
        cards = gameCards.map { Card(imageName: $0) }
        moves = 0 // Сброс количества ходов при начале новой игры
        matchedPairs = 0 // Сброс количества найденных пар при начале новой игры
        gameCompleted = false // Игра не завершена
    }
    
    /// Функция обработки переворота карточки
    func flipCard(_ card: Card) {
        // Находим индекс переворачиваемой карточки
        guard let index = cards.firstIndex(where: { $0.id == card.id }) else { return }
        
        // Проверяем, не перевернута ли карточка или не найдена ли пара
        if cards[index].isFlipped || cards[index].isMatched {
            return
        }
        
        // Переворачиваем карточку
        cards[index].isFlipped.toggle()
        flippedCards.append(cards[index])
        
        // Увеличиваем количество ходов, только когда перевернуты две карточки
        if flippedCards.count == 2 {
            moves += 1 // Увеличиваем количество ходов
            checkForMatch()
        }
    }
    
    /// Проверка на совпадение перевернутых карточек
    private func checkForMatch() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { // Небольшая задержка для эффекта
            if self.flippedCards[0].imageName == self.flippedCards[1].imageName {
                self.markCardsAsMatched() // Если совпадают
                self.matchedPairs += 1 // Увеличиваем количество найденных пар
                self.checkGameCompletion() // Проверка на завершение игры
            } else {
                self.unflipCards() // Если не совпадают
            }
            self.flippedCards.removeAll() // Очищаем массив перевернутых карточек
        }
    }
    
    /// Пометить карточки как найденные пары
    private func markCardsAsMatched() {
        for flippedCard in flippedCards {
            if let index = cards.firstIndex(where: { $0.id == flippedCard.id }) {
                cards[index].isMatched = true
            }
        }
    }
    
    /// Перевернуть карточки обратно
    private func unflipCards() {
        for flippedCard in flippedCards {
            if let index = cards.firstIndex(where: { $0.id == flippedCard.id }) {
                cards[index].isFlipped = false
            }
        }
    }
    
    /// Проверка на завершение игры
    private func checkGameCompletion() {
        if matchedPairs == cards.count / 2 {
            gameCompleted = true // Все пары найдены, игра завершена
        }
    }
    
    /// Получить рекорд
    func getRecord() -> Int {
        if moves < record {
            record = moves
        }
        return record
    }
}
