//
//  GameOverView.swift
//  FindThePair
//
//  Created by koilubaev_barsbek on 14/2/25.
//

import SwiftUI

struct GameOverView: View {
    var onRestart: () -> Void // Замыкание для перезапуска игры
    
    var body: some View {
        VStack {
            Text("Поздравляем!")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.green)
                .padding()
            
            Text("Вы нашли все пары!")
                .font(.title2)
                .padding(.bottom, 20)
            
            Button(action: {
                onRestart() // Вызываем функцию перезапуска
            }) {
                Text("Играть снова")
                    .font(.title)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding(.top, 20)
        }
    }
}
