//
//  CardView.swift
//  FindThePair
//
//  Created by koilubaev_barsbek on 19/12/24.
//

import SwiftUI

struct CardView: View {
    let card: Card // Модель карточки
    
    var body: some View {
        ZStack {
            if card.isFlipped || card.isMatched {
                // Лицо карточки (изображение)
                Image(card.imageName)
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(10)
            } else {
                // Обратная сторона карточки
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.blue)
            }
        }
        .frame(width: 70, height: 100) // Размер карточки
    }
}
