//
//  MainView.swift
//  FindThePair
//
//  Created by koilubaev_barsbek on 19/12/24.
//
import SwiftUI
import FirebaseAuth
import FirebaseCore

struct MainView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Добро пожаловать!")
                    .font(.largeTitle)
                
                if Auth.auth().currentUser != nil {
                    ContentView() // Если пользователь авторизован, перейти на экран игры
                } else {
                    // Если пользователь не авторизован, показываем кнопки регистрации и входа
                    NavigationLink("Регистрация", destination: RegistrationView())
                        .font(.title2)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    
                    NavigationLink("Вход", destination: LoginView())
                        .font(.title2)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
            .padding()
        }
    }
}
