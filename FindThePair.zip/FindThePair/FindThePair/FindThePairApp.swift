//
//  FindThePairApp.swift
//  FindThePair
//
//  Created by koilubaev_barsbek on 10/12/24.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth

@main
struct FindThePairApp: App {
    init() {
        FirebaseApp.configure() // Инициализация Firebase
    }
    
    var body: some Scene {
        WindowGroup {
            Registration()
        }
    }
}
