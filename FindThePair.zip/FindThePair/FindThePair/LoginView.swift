//
//  LoginView.swift
//  FindThePair
//
//  Created by koilubaev_barsbek on 19/12/24.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth
struct LoginView: View {
    @Binding var isAuthenticated: Bool // Связка с флагом авторизации
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage = ""
    @State private var showingAlert = false
    
    var body: some View {
        VStack {
            Text("Авторизация")
                .font(.largeTitle)
                .padding(.bottom, 40)
            
            TextField("Email", text: $email)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)
            
            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)
            
            Button(action: {
                signInWithEmail()
            }) {
                Text("Войти")
                    .frame(width: 200, height: 50)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.top, 20)
            }
            
            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding(.top, 10)
            }
        }
        .padding()
        .alert(isPresented: $showingAlert) {
            Alert(title: Text("Ошибка"), message: Text(errorMessage), dismissButton: .default(Text("OK")))
        }
    }
    
    private func signInWithEmail() {
        FirebaseAuth.Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                self.errorMessage = error.localizedDescription
                self.showingAlert = true
            } else {
                self.isAuthenticated = true
            }
        }
    }
}
