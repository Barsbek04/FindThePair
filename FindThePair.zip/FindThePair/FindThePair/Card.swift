//
//  Card.swift
//  FindThePair
//
//  Created by koilubaev_barsbek on 10/12/24.
//

import Foundation

struct Card: Identifiable {
    let id = UUID()          // Уникальный идентификатор для каждой карточки
    let imageName: String    // Имя изображения, связанного с карточкой
    var isFlipped = false    // Указывает, перевернута ли карточка
    var isMatched = false    // Указывает, найдена ли пара для этой карточки
}
