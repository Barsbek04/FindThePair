//
//  RegistratinView.swift
//  FindThePair
//
//  Created by koilubaev_barsbek on 19/12/24.
//

import SwiftUI
import Firebase
import FirebaseAuth

// Основной экран, который контролирует состояние аутентификации
struct Registration: View {
    
    // Состояние для отслеживания, залогинен ли пользователь
    @State var status = UserDefaults.standard.value(forKey: "status") as? Bool ?? false
    
    var body: some View {
        
        VStack {
            
            // Если статус = true, показываем ваш ContentView, если нет — экран входа
            if status {
                ContentView()  // Ваш ContentView, который заменяет экран Home
            } else {
                SignIn()  // Экран входа
            }
            
        }
        .animation(.spring())  // Анимация для плавных переходов
        .onAppear {
            // Добавление наблюдателя на изменение статуса аутентификации
            NotificationCenter.default.addObserver(forName: NSNotification.Name("statusChange"), object: nil, queue: .main) { (_) in
                let status = UserDefaults.standard.value(forKey: "status") as? Bool ?? false
                self.status = status
            }
        }
    }
}

// Экран входа в систему, где пользователь вводит логин и пароль
struct SignIn: View {
    
    // Состояния для ввода данных пользователя
    @State var user = ""
    @State var pass = ""
    @State var message = ""
    @State var alert = false
    @State var show = false
    
    var body: some View {
        VStack {
            VStack {
                // Заголовок экрана
                Text("Sign In")
                    .fontWeight(.heavy)
                    .font(.largeTitle)
                    .padding([.top, .bottom], 20)
                
                VStack(alignment: .leading) {
                    // Поле для ввода имени пользователя
                    VStack(alignment: .leading) {
                        Text("Username")
                            .font(.headline)
                            .fontWeight(.light)
                            .foregroundColor(Color.init(.label).opacity(0.75))
                        
                        HStack {
                            // Текстовое поле для ввода имени пользователя
                            TextField("Enter Your Username", text: $user)
                            
                            if user != "" {
                                // Иконка, если имя пользователя введено
                                Image("check").foregroundColor(Color.init(.label))
                            }
                        }
                        Divider()  // Разделитель
                    }
                    .padding(.bottom, 15)
                    
                    // Поле для ввода пароля
                    VStack(alignment: .leading) {
                        Text("Password")
                            .font(.headline)
                            .fontWeight(.light)
                            .foregroundColor(Color.init(.label).opacity(0.75))
                        
                        SecureField("Enter Your Password", text: $pass)
                        Divider()  // Разделитель
                    }
                    
                }
                .padding(.horizontal, 6)
                
                // Кнопка для отправки данных входа
                Button(action: {
                    signInWithEmail(email: self.user, password: self.pass) { (verified, status) in
                        if !verified {
                            // Если вход не успешен, показываем ошибку
                            self.message = status
                            self.alert.toggle()
                        } else {
                            // Если вход успешен, сохраняем статус и отправляем уведомление
                            UserDefaults.standard.set(true, forKey: "status")
                            NotificationCenter.default.post(name: NSNotification.Name("statusChange"), object: nil)
                        }
                    }
                }) {
                    // Текст кнопки
                    Text("Sign In")
                        .foregroundColor(.white)
                        .frame(width: UIScreen.main.bounds.width - 120)
                        .padding()
                }
                .background(Color("color"))  // Цвет фона кнопки
                .clipShape(Capsule())  // Закругленные углы кнопки
                .padding(.top, 45)
                
            }
            .padding()
            
            // Показываем алерт, если возникла ошибка при входе
            .alert(isPresented: $alert) {
                Alert(title: Text("Error"), message: Text(self.message), dismissButton: .default(Text("Ok")))
            }
            
            VStack {
                // Разделитель для отображения текста "или"
                Text("(or)").foregroundColor(Color.gray.opacity(0.5)).padding(.top, 30)
                
                // Кнопка для перехода на экран регистрации
                HStack(spacing: 8) {
                    Text("Don't Have An Account ?").foregroundColor(Color.gray.opacity(0.5))
                    
                    Button(action: {
                        self.show.toggle()  // Показать экран регистрации
                    }) {
                        Text("Sign Up")
                    }
                    .foregroundColor(.blue)
                    
                }
                .padding(.top, 25)
            }
            // Экран регистрации
            .sheet(isPresented: $show) {
                RegistrationView(show: self.$show)  // Здесь используем RegistrationView вместо SignUp
            }
        }
    }
}

// Экран регистрации пользователя
struct RegistrationView: View {
    
    // Состояния для ввода данных регистрации
    @State var user = ""
    @State var pass = ""
    @State var message = ""
    @State var alert = false
    @Binding var show: Bool
    
    var body: some View {
        VStack {
            Text("Sign Up")
                .fontWeight(.heavy)
                .font(.largeTitle)
                .padding([.top, .bottom], 20)
            
            VStack(alignment: .leading) {
                // Поле для ввода имени пользователя
                VStack(alignment: .leading) {
                    Text("Username")
                        .font(.headline)
                        .fontWeight(.light)
                        .foregroundColor(Color.init(.label).opacity(0.75))
                    
                    HStack {
                        TextField("Enter Your Username", text: $user)
                        if user != "" {
                            Image("check").foregroundColor(Color.init(.label))
                        }
                    }
                    Divider()
                }
                .padding(.bottom, 15)
                
                // Поле для ввода пароля
                VStack(alignment: .leading) {
                    Text("Password")
                        .font(.headline)
                        .fontWeight(.light)
                        .foregroundColor(Color.init(.label).opacity(0.75))
                    
                    SecureField("Enter Your Password", text: $pass)
                    Divider()
                }
                
            }
            .padding(.horizontal, 6)
            
            // Кнопка для регистрации
            Button(action: {
                signUpWithEmail(email: self.user, password: self.pass) { (verified, status) in
                    if !verified {
                        self.message = status
                        self.alert.toggle()
                    } else {
                        UserDefaults.standard.set(true, forKey: "status")
                        self.show.toggle()
                        NotificationCenter.default.post(name: NSNotification.Name("statusChange"), object: nil)
                    }
                }
            }) {
                Text("Sign Up")
                    .foregroundColor(.white)
                    .frame(width: UIScreen.main.bounds.width - 120)
                    .padding()
            }
            .background(Color("color"))
            .clipShape(Capsule())
            .padding(.top, 45)
            
        }
        .padding()
        .alert(isPresented: $alert) {
            Alert(title: Text("Error"), message: Text(self.message), dismissButton: .default(Text("Ok")))
        }
    }
}

// Функция для входа в систему
func signInWithEmail(email: String, password: String, completion: @escaping (Bool, String) -> Void) {
    Auth.auth().signIn(withEmail: email, password: password) { (res, err) in
        if err != nil {
            completion(false, (err?.localizedDescription)!)  // Возвращаем ошибку, если вход не удался
            return
        }
        completion(true, (res?.user.email)!)  // Возвращаем успешный результат
    }
}

// Функция для регистрации пользователя
func signUpWithEmail(email: String, password: String, completion: @escaping (Bool, String) -> Void) {
    Auth.auth().createUser(withEmail: email, password: password) { (res, err) in
        if err != nil {
            completion(false, (err?.localizedDescription)!)  // Возвращаем ошибку, если регистрация не удалась
            return
        }
        completion(true, (res?.user.email)!)  // Возвращаем успешный результат
    }
}

// Превью для отображения экрана в симуляторе
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
