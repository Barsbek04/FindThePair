//
//  ContentView.swift
//  FindThePair
//
//  Created by koilubaev_barsbek on 10/12/24.
//


//
//  ContentView.swift
//  FirebaseExample
//
//  Created by Ian Solomein on 15.08.2020.
//  Copyright © 2020 Ian Solomein. All rights reserved.
//


import SwiftUI
import Firebase
import FirebaseAuth

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home() // Сразу загружаем экран игры
    }
}

import SwiftUI
import FirebaseAuth

struct SignInView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage = ""
    @State private var showSignUp = false // Флаг для показа регистрации
    @State private var isLoggedIn = false // Флаг успешного входа
    
    var body: some View {
        if isLoggedIn {
            Home() // Если вошел, сразу переходим в игру
        } else {
            VStack {
                Text("Вход в игру")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()
                
                TextField("Введите email", text: $email)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .autocapitalization(.none)
                    .padding()
                
                SecureField("Введите пароль", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Button(action: login) {
                    Text("Войти")
                        .font(.title)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()
                
                if !errorMessage.isEmpty {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .padding()
                }
                
                Button(action: {
                    showSignUp = true
                }) {
                    Text("Регистрация")
                        .foregroundColor(.blue)
                }
                .padding()
            }
            .padding()
            .sheet(isPresented: $showSignUp) {
                SignUpView(isPresented: $showSignUp)
            }
        }
    }
    
    func login() {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                errorMessage = error.localizedDescription
            } else {
                isLoggedIn = true // Успешный вход
            }
        }
    }
}


import SwiftUI
import FirebaseAuth

struct SignUpView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage = ""
    @Binding var isPresented: Bool
    
    var body: some View {
        VStack {
            Text("Регистрация")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
            
            TextField("Введите email", text: $email)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(.none)
                .padding()
            
            SecureField("Введите пароль", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button(action: signUp) {
                Text("Зарегистрироваться")
                    .font(.title)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding()
            
            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }
            
            Button(action: {
                isPresented = false
            }) {
                Text("Уже есть аккаунт? Войти")
                    .foregroundColor(.blue)
            }
            .padding()
        }
        .padding()
    }
    
    func signUp() {
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                errorMessage = error.localizedDescription
            } else {
                isPresented = false // Закрываем регистрацию после успеха
            }
        }
    }
}
struct Home: View {
    @StateObject private var viewModel = GameViewModel() // ViewModel игры
    @State private var showGameOverScreen = false // Флаг для показа экрана поздравления
    
    var body: some View {
        VStack {
            Text("Найди пару")
                .font(.largeTitle)
                .padding()
            
            Text("Ходы: \(viewModel.moves)")
                .font(.title2)
                .padding(.bottom)
            
            Text("Найдено пар: \(viewModel.matchedPairs) / 8")
                .font(.title2)
                .padding(.bottom)
            
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4)) {
                ForEach(viewModel.cards) { card in
                    CardView(card: card)
                        .onTapGesture {
                            viewModel.flipCard(card)
                        }
                        .padding(5)
                }
            }
            
            // Кнопка "Заново" - сбрасывает игру в любой момент
            Button(action: {
                viewModel.startGame()
            }) {
                Text("Заново")
                    .font(.title2)
                    .padding()
                    .background(Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding(.top, 20)
        }
        .padding()
        .onAppear {
            viewModel.startGame()
        }
        .onChange(of: viewModel.gameCompleted) { isCompleted in
            if isCompleted {
                showGameOverScreen = true
            }
        }
        .fullScreenCover(isPresented: $showGameOverScreen) {
            GameOverView {
                viewModel.startGame()
                showGameOverScreen = false
            }
        }
    }
}

// CardView - Отображение одной карточки
struct CardView: View {
    let card: Card // Модель карточки
    
    var body: some View {
        ZStack {
            if card.isFlipped || card.isMatched {
                // Лицо карточки (изображение)
                Image(card.imageName)
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(10)
            } else {
                // Обратная сторона карточки
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.blue)
            }
        }
        .frame(width: 70, height: 100) // Размер карточки
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
