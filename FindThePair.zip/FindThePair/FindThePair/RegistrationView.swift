//
//  RegistrationView.swift
//  FindThePair
//
//  Created by koilubaev_barsbek on 19/12/24.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth

struct RegistrationView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var errorMessage = ""
    @State private var isRegistered = false

    var body: some View {
        VStack(spacing: 20) {
            Text("Регистрация")
                .font(.largeTitle)
                .bold()
                .padding()

            TextField("Введите email", text: $email)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.emailAddress)
                .autocapitalization(.none)

            SecureField("Введите пароль", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            SecureField("Подтвердите пароль", text: $confirmPassword)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            Button(action: registerUser) {
                Text("Зарегистрироваться")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .disabled(email.isEmpty || password.isEmpty || confirmPassword.isEmpty)

            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .multilineTextAlignment(.center)
                    .padding()
            }

            if isRegistered {
                Text("Вы успешно зарегистрированы!")
                    .foregroundColor(.green)
                    .onTapGesture {
                        // Переход на экран игры после успешной регистрации
                        // Например, просто запустите игру или откройте главный экран
                        startGame()
                    }
            }
        }
        .padding()
    }

    private func registerUser() {
        guard password == confirmPassword else {
            errorMessage = "Пароли не совпадают"
            return
        }

        // Firebase регистрация пользователя
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                errorMessage = "Ошибка: \(error.localizedDescription)"
            } else {
                isRegistered = true
                errorMessage = ""
            }
        }
    }

    private func startGame() {
        // Здесь вы можете начать игру, например, переход на экран игры.
        // Для примера: NavigationLink или смена представления.
    }
}
